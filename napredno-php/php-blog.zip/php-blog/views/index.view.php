

<?php require 'views/partials/head.php' ?>
  
  <div class="container mt-4">
    <div class="jumbotron bg-secondary text-white p-4 mb-4 rounded">
      <h1><?= $naslov?></h1>
      <h2>Dobrodošli na moj PHP blog.</h2>
      <p>Jednostavna PHP aplikacija napravljana koristeći MVC pattern</p>
    </div>
  </div>
  
  <?php require 'views/partials/foot.php' ?>
