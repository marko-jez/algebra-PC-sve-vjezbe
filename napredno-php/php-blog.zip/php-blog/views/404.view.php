<?php require 'views/partials/head.php';?>



<div class="container jumbotron bg-warning p-4 m-4 rounded mx-auto">
  <h2 class="my-4">Nešto je pošlo po zlu. Nismo pronašli ovu stranicu</h2>

  <a href="/"> Natrag na početnu</a>

</div>


<?php require 'views/partials/foot.php'; ?>