# Dokumentacija projekta
## PHP Blog
Ovo je naša prva aplikacija koja objedinuje sve što smo do sada naučili kroz primjenu MVC patterna.

APlikacije neće biti prekompleksna, već joj je cilj koristiti stečeno znanje koje je kasnije primjenjivo i drugdje 


## User Storyi:
1. Kao korisnik aplikacije, na počenoj stranici želim vidjeti sve blogove koje sam napisao te želim vidjeti detalje o tim blogovima
2. Kao korisnik aplikacije, na stranici pojedinog bloga želim vidjeti cijeli tekst bloga, datum i vrijem objave, autora te se skeciju komentara.