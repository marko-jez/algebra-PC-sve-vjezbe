<?php

$naslov = 'Blog o programiranju';


require 'views/index.view.php';
