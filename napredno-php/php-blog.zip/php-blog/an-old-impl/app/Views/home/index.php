 <div class="container">
  <div class="jumbotron bg-secondary text-white p-4 mb-4 rounded">
    <h2>Dobrodošli na moj PHP blog.</h2>
    <p>Jednostavna PHP aplikacija napravljana koristeći MVC pattern</p>
    <h3>Bok, <?= $ime ?></h3>
  </div>
 </div>