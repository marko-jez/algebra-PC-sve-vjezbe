<?php require __DIR__ . '/../views/partials/head.php' ?>


<div class="container mt-4">
  <?php foreach($zadaci as $zadatak) :?>
    <article class="rounded border p-4 border-dark m-4">
      <h2><?= $zadatak['naslov'] ?></h2>
      <p><?= $zadatak['opis'] ?></p>
      <small><?= $zadatak['status'] ?></small>
      <small><?= $zadatak['createdAt'] ?></small>
      <!-- <form action="/articles-delete" method="POST">
        <input type="hidden" name="id" value="<?=$article['id']?>">
        <input type="submit" value="Obriši" />
      </form> -->
      <!-- <a href="/articles-edit?id=<?=$article['id']?>">Ažuriraj članak</a> -->
    </article>
  <?php endforeach; ?>
</div>

<?php require __DIR__ . '/../views/partials/foot.php' ?>