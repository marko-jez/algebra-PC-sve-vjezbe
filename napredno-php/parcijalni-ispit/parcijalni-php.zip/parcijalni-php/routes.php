<?php

return [
  '/' => 'HomeController.php',
  '/liste' => 'liste/index.php',
];