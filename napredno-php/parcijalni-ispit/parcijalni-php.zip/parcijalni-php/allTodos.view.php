<div class="container mt-4">
  <div class="d-flex p-2 flex-column-reverse">
    <!-- mjesto za foreach i todo-ove -->

  </div>
</div>