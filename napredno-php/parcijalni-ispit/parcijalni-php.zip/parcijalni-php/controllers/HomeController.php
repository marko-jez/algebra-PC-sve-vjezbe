<?php

view('index.view.php');