<?php

require __DIR__ . '/../../models/Liste.php';

$listeZadataka = new Liste;

$liste = $listeZadataka->getAll();

$zadaci = array_values($liste);

view('listeZadataka/index.view.php', [
  'zadaci' => $zadaci
  ]);